package com.movie.managers;

import com.movie.models.Movie;
import com.movie.exception.*;

import java.util.*;

public abstract class MovieManager extends MovieOperation {

     ArrayList<Movie> Movie = new ArrayList<>();
     
     public MovieManager() {
    	 Movie.add(new Movie(1, "Movie 1", "A", 2000, 9, "Horror"));
    	 Movie.add(new Movie(3, "Movie 2", "B", 2013, 8, "Action"));
    	 Movie.add(new Movie(5, "Movie 3", "C", 2026, 9, "Action"));
    	 Movie.add(new Movie(4, "Movie 4", "D", 2002, 5, "Comedy"));
    	 Movie.add(new Movie(2, "Movie 5", "E", 2017, 6, "SuperHero"));    	 
     }
     
     Scanner sc = new Scanner(System.in);

    @Override
    public void addMovie() throws DuplicateMovieIdException {

        try {

            System.out.print("Enter Movie ID: ");
            int id = sc.nextInt();
            sc.nextLine();

            for (Movie b : Movie) {
                if (b.getMovieID() == id) {
                    throw new DuplicateMovieIdException("Movie ID already exists!");
                }
            }

            System.out.print("Enter Title: ");
            String title = sc.nextLine();
            
            System.out.print("Enter Author: ");
            String director = sc.nextLine();

            System.out.print("Enter Price: ");
            String genre = sc.nextLine();

            System.out.print("Enter Rating: ");
            int rating = sc.nextInt();

            System.out.print("Enter Publication Year: ");
            int year = sc.nextInt();


            Movie Movie = new Movie(id, title, director, rating, year);

            Movie.add(Movie);

            System.out.println("Movie added successfully.");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void viewMovie() {

        if (Movie.isEmpty()) {
            System.out.println("No Movie available.");
            return;
        }
        for (Movie b : Movie) {
            System.out.println(b);
        }
    }

    @Override
    public void searchMovie() throws MovieNotFoundException {

        try {

            System.out.print("Enter Movie ID to search: ");
            int id = sc.nextInt();

            for (Movie b : Movie) {
                if (b.getMovieID() == id) {
                    System.out.println(b);
                    return;
                }
            }

            throw new MovieNotFoundException("Movie not found!");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void updateMovie() throws MovieNotFoundException {

        try {

            System.out.print("Enter Movie ID to update: ");
            int id = sc.nextInt();
            sc.nextLine();

            for (Movie b : Movie) {

                if (b.getMovieID() == id) {

                    System.out.print("Enter New Title: ");
                    b.setTitle(sc.nextLine());

                    System.out.print("Enter New Author: ");
                    b.setDirector(sc.nextLine());

                    System.out.print("Enter New Price: ");
                    b.setGenre(sc.nextLine());

                    System.out.print("Enter New Rating: ");
                    b.setRating(sc.nextInt());

                    System.out.print("Enter New Publication Year: ");
                    b.setReleaseYear(sc.nextInt());

                    System.out.println("Movie updated successfully.");
                    return;
                }
            }

            throw new MovieNotFoundException("Movie not found!");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void deleteMovie() throws MovieNotFoundException{

        try {

            System.out.print("Enter Movie ID to delete: ");
            int id = sc.nextInt();

            Iterator<Movie> it = Movie.iterator();

            while (it.hasNext()) {

                Movie b = it.next();

                if (b.getMovieID() == id) {
                    it.remove();
                    System.out.println("Movie deleted successfully.");
                    return;
                }
            }

            throw new MovieNotFoundException("Movie not found!");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void sortByTitle() {

        Collections.sort(Movie, (b1, b2) ->
                b1.getTitle().compareToIgnoreCase(b2.getTitle()));

        System.out.println("Sorted by Title.");
        viewMovie();
    }

    
    @Override
    public void sortByDirector() {

        Collections.sort(Movie, (b1, b2) ->
                b1.getD().compareToIgnoreCase(b2.getDirector()));

        System.out.println("Sorted by Author.");
        viewMovie();
    }


    @Override
    public void sortByRating() {

        Collections.sort(Movie, (b1, b2) ->
                Double.compare(b2.getRating(), b1.getRating()));

        System.out.println("Sorted by Rating.");
        viewMovie();
    }

    @Override
    public void sortByreleaseYear() {

        Collections.sort(Movie, (b1, b2) ->
                Integer.compare(b1.getReleaseYear(), b2.getReleaseYear()));

        System.out.println("Sorted by Publication Year.");
        viewMovie();
    }
}